﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH_Elotti_Feladat
{
    class Program
    {
        static void Main(string[] args)
        {

            ValosSzamok feladat1 = new ValosSzamok();
            HaromJegyuSzamok feladat2 = new HaromJegyuSzamok();
            AtlagErtek feladat3 = new AtlagErtek();
        }
    }
}
