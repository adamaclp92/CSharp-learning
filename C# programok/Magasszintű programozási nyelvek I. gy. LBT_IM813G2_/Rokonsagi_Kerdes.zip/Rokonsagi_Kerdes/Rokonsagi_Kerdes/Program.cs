﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rokonsagi_Kerdes
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime DatumErtek = (DateTime.Now);
            int ev = DatumErtek.Year;

            string RokonNev1 = "";
            string RokonNev2 = "";
            int RokonSzulEv1;
            int RokonSzulEv2;
            int Kulonbseg;

            Console.WriteLine("Kérem az első Férfi nevet:");
            RokonNev1 = Console.ReadLine();
            Console.WriteLine("Kérem {0} születési évét:", RokonNev1);
            RokonSzulEv1 = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Kérem az második Férfi nevet:");
            RokonNev2 = Console.ReadLine();
            Console.WriteLine("Kérem {0} születési évét:", RokonNev2);
            RokonSzulEv2 = Int32.Parse(Console.ReadLine());

            RokonSzulEv1 = ev - RokonSzulEv1;
            RokonSzulEv2 = ev - RokonSzulEv2;

            Kulonbseg = RokonSzulEv1 - RokonSzulEv2;

            Console.WriteLine(Kulonbseg);

            if (Kulonbseg >= 0)
            {
                if (Kulonbseg < 18)
                {
                    Console.WriteLine("{0} valószínüleg Testvére {1}", RokonNev1, RokonNev2);
                }
                else if (Kulonbseg <= 40)
                {
                    Console.WriteLine("valószínűleg {0} az apja {1}-nak", RokonNev1, RokonNev2);
                }
                else if (Kulonbseg < 60)
                {
                    Console.WriteLine("valószínűleg {0} az nagyapja {1}-nak", RokonNev1, RokonNev2);
                }
                else
                {
                    Console.WriteLine("valószínűleg {0} az dédnagypapája {1}-nak", RokonNev1, RokonNev2);
                }
            }
            else
            {
                Kulonbseg = Math.Abs(Kulonbseg);
                if (Kulonbseg < 18)
                {
                    Console.WriteLine("{1} valószínüleg Testvére {0}", RokonNev1, RokonNev2);
                }
                else if (Kulonbseg <= 40)
                {
                    Console.WriteLine("valószínűleg {1} az apja {0}-nak", RokonNev1, RokonNev2);
                }
                else if (Kulonbseg < 60)
                {
                    Console.WriteLine("valószínűleg {0} az unokája {1}-nak", RokonNev1, RokonNev2);
                }
                else
                {
                    Console.WriteLine("valószínűleg {0} az ükunokája {1}-nak", RokonNev1, RokonNev2);
                }
            }
            Console.ReadKey();
        }
    }
}
