﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Szamok_Osszege
{
    class Program
    {
        static void Main(string[] args)
        {
            int SzamOsszeg = 0;
            int Szam;
            int MinSzam = 0;
            int MaxSzam = 0;
            int SzamDb = 0;
            bool ParosE = false;
            Console.WriteLine("Pozítiv egész számokat kérek MAXIMUM 10 szám beírásával el kell érni a 100-at egyébként kilépek.");
            do
            {
                Console.WriteLine("Kérem a számot!");
                Szam = Int32.Parse(Console.ReadLine());
                if (Szam > 0)
                {
                    SzamOsszeg += Szam;

                    if (MinSzam > Szam || MinSzam == 0)
                        MinSzam = Szam;

                    if (MaxSzam < Szam)
                        MaxSzam = Szam;

                    if (Szam % 2 == 0)
                        ParosE = true;

                    SzamDb++;
                }
                else
                    Console.WriteLine("A szám kisebb mint nulla");
            } while (SzamOsszeg < 100 && SzamDb < 10);

            Console.WriteLine("A legkisebb szám: {0}", MinSzam);
            Console.WriteLine("A legnagyobb szám: {0}", MaxSzam);
            if (ParosE)
                Console.WriteLine("A számok között volt páros szám");
            else
                Console.WriteLine("A számok között nem volt páros szám");

            Console.ReadKey();
        }
    }
}
