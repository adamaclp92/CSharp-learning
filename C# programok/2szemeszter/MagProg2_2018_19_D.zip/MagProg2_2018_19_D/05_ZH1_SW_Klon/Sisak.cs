﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_ZH1_SW_Klon
{
    enum Sisak
    {
        KLASSZIKUS,
        EBREDOEROS,
        FELDERITO
    }
}
