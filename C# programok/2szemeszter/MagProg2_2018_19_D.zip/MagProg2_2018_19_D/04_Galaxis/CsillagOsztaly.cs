﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace _04_Galaxis
{
    enum CsillagOsztaly
    {
        VOROSORIAS,
        BARNATORPE,
        NEUTRON,
        HALAL,
        HALAL2,        
        FEHERORIAS
    }
}
