﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03_Vilagmindenseg
{
    enum CsillagOsztaly
    {
        BARNATORPE,
        VOROSORIAS,        
        FEHERTORPE,
        HALAL,
        HALAL2,
        NEUTRON,
        VOROSTORPE
    }
}
