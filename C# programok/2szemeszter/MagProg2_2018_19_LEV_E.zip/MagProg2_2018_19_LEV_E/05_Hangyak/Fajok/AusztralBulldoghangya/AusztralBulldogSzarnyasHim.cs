﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_Hangyak
{
    class AusztralBulldogSzarnyasHim : ASzarnyasHim
    {
        public AusztralBulldogSzarnyasHim()
            :base(0, ConsoleColor.Blue, Faj.AUSZTRALBULLDOG)
        {

        }
    }
}
