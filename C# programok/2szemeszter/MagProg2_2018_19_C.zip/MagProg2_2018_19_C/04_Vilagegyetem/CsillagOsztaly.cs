﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_Vilagegyetem
{
    enum CsillagOsztaly
    {
        NEUTRON,
        BARNATORPE,
        HALAL,
        HALAL2,
        VOROSORIAS,
        VOROSTORPE,
        FEHERORIAS,
        UJ_KATEGORIA
    }
}
