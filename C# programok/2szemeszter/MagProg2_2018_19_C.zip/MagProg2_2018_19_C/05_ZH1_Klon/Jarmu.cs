﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05_ZH1_Klon
{
    enum Jarmu
    {
        ATAT,
        TIE,
        ATST
    }
}
